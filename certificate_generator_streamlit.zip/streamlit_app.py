
import streamlit as st
import pandas as pd
from docx import Document
import base64
import io
import zipfile

# Replace placeholders in Word template
def fill_certificate(template_bytes, row):
    doc = Document(io.BytesIO(template_bytes))
    replacements = {
        "[NAME]": str(row.get("Name", "")),
        "[IQAMA]": str(row.get("IQAMA", "")),
        "[EMP_NO]": str(row.get("Emp No", "")),
        "[EQUIPMENT]": str(row.get("Equipment", "")),
        "[COMPANY]": str(row.get("Company", "Quality Performance Inspection company")),
        "[ISSUE_DATE]": str(row.get("Issue Date", "")),
        "[EXPIRY_DATE]": str(row.get("Expiry Date", "")),
        "[CERT_NO]": str(row.get("Cert No", ""))
    }
    for paragraph in doc.paragraphs:
        for key, value in replacements.items():
            if key in paragraph.text:
                paragraph.text = paragraph.text.replace(key, value)
    output = io.BytesIO()
    doc.save(output)
    return output.getvalue()

# Web interface
st.title("Certificate Generator - QPI")
st.markdown("Upload a Word template with placeholders like [NAME], [IQAMA], etc., and an Excel file with the data.")

template_file = st.file_uploader("Upload Word Template (.docx)", type="docx")
data_file = st.file_uploader("Upload Excel Data (.xlsx)", type="xlsx")

if template_file and data_file:
    df = pd.read_excel(data_file)
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "a", zipfile.ZIP_DEFLATED) as zipf:
        for index, row in df.iterrows():
            cert_bytes = fill_certificate(template_file.read(), row)
            cert_name = f"{row.get('Name', 'Certificate')}.docx"
            zipf.writestr(cert_name, cert_bytes)
    zip_buffer.seek(0)
    b64 = base64.b64encode(zip_buffer.read()).decode()
    href = f'<a href="data:application/zip;base64,{b64}" download="Certificates.zip">Download Certificates ZIP</a>'
    st.markdown(href, unsafe_allow_html=True)
else:
    st.info("Please upload both a template and a data file.")
